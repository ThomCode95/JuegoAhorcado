package com.tallercmovil.ahorcado;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.app.Dialog;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.os.Bundle;
import java.util.Random;
import android.graphics.Color;
import android.widget.LinearLayout;
import android.widget.GridView;
import android.content.Context;

//////////////////////////
import android.widget.Button;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GameActivity extends AppCompatActivity {

    private String[] words;
    private Random random;
    private String currWord;//palabra actual
    private TextView[] charViews;//arreglo de textView
    private TextView charViewCategory;//arreglo de textView
    private LinearLayout wordLayout;
    private LetterAdapter adapter;
    private GridView gridView;
    private int numCorr;
    private int numChars;
    private ImageView[]parts;
    private int sizeParts = 6;//cabeza,pecho,2 brazos, 2 piernas
    private int currPart; //parte actual del cuerpo

    //para la parte del JSON
    private RequestQueue mQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        words=getResources().getStringArray(R.array.words);
        wordLayout = findViewById(R.id.words);
        gridView = findViewById(R.id.letters);
        random = new Random();

        parts = new ImageView[sizeParts];
        parts[0] = findViewById(R.id.head); //identificar la cabeza
        parts[1] = findViewById(R.id.body); //identificar cuerpo
        parts[2] = findViewById(R.id.armLeft); //identificar brazo izquierdo
        parts[3] = findViewById(R.id.armRight); //identificarbrazo derecho
        parts[4] = findViewById(R.id.legLeft); //identificar pierna izquierda
        parts[5] = findViewById(R.id.legRight); //identificar pierna derecha

        //PARTE DEL JSON
        //jsonParse();
        mQueue = Volley.newRequestQueue(this);



        jsonParse();

    }
//JASON PARSE
private void jsonParse() {
    String url = "https://www.serverbpw.com/cm/2021-1/hangman.php";
    JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
            new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    String string = String.valueOf(response);
                    String[] parts = string.split(",");
                    String part1 = parts[0]; // 004
                    String part2 = parts[1]; // 034556
                    int length1 = part1.length();
                    int length2 = part2.length();
                    String nuevoString1 = part1.substring(9, length1 -1);
                    String palabra = nuevoString1.toUpperCase();

                    String nuevoString2 = part2.substring(12, length2 -2);
                    String categoria = nuevoString2.toUpperCase();

                    playGame(palabra,categoria);

                }
            }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            error.printStackTrace();
        }
    });
    mQueue.add(request);
}

    private void playGame(String palabra,String categoria){

        ////////////
        //Checamos que la palabra actual no sea igual a la anterior
        //while(newWord.equals(currWord))newWord=words[random.nextInt(words.length)];

        //currWord = newWord;
        TextView textView = (TextView) findViewById(R.id.simpleTextView);
        textView.setText("Categoria: " + categoria); //set text for text view


        currWord = palabra;
        charViews = new TextView[currWord.length()];


        for(int i =0; i<currWord.length(); i++){
            charViews[i] = new TextView(this);
            charViews[i].setText(""+currWord.charAt(i));
            charViews[i].setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT));
            charViews[i].setTextColor(Color.WHITE);
            charViews[i].setBackgroundResource(R.drawable.letter_bg);
            wordLayout.addView(charViews[i]);
        }
        adapter = new LetterAdapter(this);
        gridView.setAdapter(adapter);
        numCorr = 0;
        currPart =0;
        numChars = currWord.length();
    }
    public void letterPressed(View view){
        String letter = ((TextView)view).getText().toString();
        char letterChar = letter.charAt(0);//obteniedno texto del boton
        view.setEnabled(false);//al soltar el boton se dehabilita
        boolean correct = false;//para verificar si la letra se encuentra dentro de unestra palabra


        //verifica si la letra que presiono el usuario se encuentra dentro de la palabra
        for(int i=0; i <currWord.length();i++){
            if(currWord.charAt(i) == letterChar){//comparar cada una de las letras dentro del texto
                correct = true;
                numCorr++;
                charViews[i].setTextColor(Color.BLACK);
            }
        }

        if(correct) {
            if (numCorr == numChars) {//si los caracteres correctos es igual a tamanio total de la palabra se gana el juego
                disableButtons();
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setTitle("Ganaste");
                builder.setMessage("Felicidades!\n\n La respuesta era\n\n"+currWord);
                builder.setPositiveButton("Jugar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GameActivity.this.jsonParse();
                    }
                });

                builder.setPositiveButton("Salir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GameActivity.this.finish();
                    }
                });
                builder.show();
            }
        }else if(currPart < sizeParts -1){//si se falla un intento se muestra una parte del cuerpo
            parts[currPart].setVisibility(View.VISIBLE);
            currPart++;
        }else{
            parts[5].setVisibility(View.VISIBLE);//si se falla el ultimo intento se muestra la ultima parte del cuerpo y lanza mensaje de "Perdiste"
            disableButtons();
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Perdiste");
            builder.setMessage("Lo siento!\n\n La respuesta era\n\n"+currWord);
            builder.setPositiveButton("Jugar", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    GameActivity.this.jsonParse();
                }
            });

            builder.setPositiveButton("Salir", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    GameActivity.this.finish();
                }
            });
            builder.show();
        }
    }
    public void disableButtons(){
        for(int i = 0; i<gridView.getChildCount();i++){
            gridView.getChildAt(i).setEnabled(false);
        }
    }
}