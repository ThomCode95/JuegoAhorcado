package com.tallercmovil.ahorcado;

import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.view.LayoutInflater;
import android.content.Context;

public class LetterAdapter extends BaseAdapter {
    private String[]letters;
    private LayoutInflater letterInf;

    public LetterAdapter(Context context){
        letters = new String[26];
        for(int i=0; i<letters.length;i++){
            letters[i] = ""+(char)(i+'A');//Obtenemos cada una de las letras del abecedario y las agrega al arreglo
        }
        letterInf = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return letters.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Button btnLetter;
        if(view == null){//si no hay una vista creada lo mandamos a llamar
            btnLetter = (Button)letterInf.inflate(R.layout.letter,viewGroup,false);
        }else{
            btnLetter = (Button)view;
        }
        btnLetter.setText(letters[i]);
        return btnLetter;
    }
}
