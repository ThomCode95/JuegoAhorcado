Alumno: Arias Pelayo Thomas Alejandro
Extraordinario Cómputo Móvil
Correr proyecto en android studio
Para el simulador use Pixel 3a API 21

Me base en el main activity del siguiente tutorial:
https://www.youtube.com/watch?v=l4c4IShM0Wo&feature=youtu.be&ab_channel=codigofacilito


Y para la parte del JSON me base en:
https://codinginflow.com/tutorials/android/volley/part-1-simple-get-request